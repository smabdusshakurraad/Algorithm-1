public class HelloWorld {
public HelloWorld() {
    System.out.println("Inside constructor");
	}

 public static void main(String[] args) {
    System.out.println("Hello, World");
 }
}
